<link rel="Stylesheet" href="logout.css">
<?php
    session_start();
    session_destroy();
?>
<main>
    <p><a href="home.php">HOME</a></p>
</main>
